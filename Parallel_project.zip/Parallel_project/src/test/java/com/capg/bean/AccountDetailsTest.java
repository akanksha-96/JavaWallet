package com.capg.bean;

import junit.framework.TestCase;

public class AccountDetailsTest extends TestCase {

	public void testGetAge() {
		assertEquals(22,8);
	}

	public void testGetAadharNo() {
		
		
		assertEquals("121345687401","");
		
	}

	
	public void testGetCustName() {
		
		assertEquals("Akanksha","Ak");
	}

	
	
	
	public void testGetGender() {
		assertNotSame("male","m");
		assertEquals("female","f");
	}

	

	public void testGetCustMobileNo() {
		assertEquals("9547812345","");
	}

	

	public void testGetCustAddress() {
		assertEquals("Jaipur","jai");
	}

	
	/*public void testGetCustEmail() {
		assertEquals("abc@gmail.com","abc@gmail.com");
	}*/



	public void testGetCustBal() {
		assertEquals(25000,10000);
	}

	public void testGetNationality() {
		assertEquals("Indian","Indian");
	}

	

	public void testGetCustAccNo() {
		assertEquals("812547812345","");
	}



	/*public void testGetuPassword() {
		fail("Not yet implemented");
	}*/

	

}
