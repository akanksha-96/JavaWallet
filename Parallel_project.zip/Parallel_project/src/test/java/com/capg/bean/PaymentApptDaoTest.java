package com.capg.bean;
import com.capg.dao.PaymentAppDao;

import junit.framework.Assert;
import junit.framework.TestCase;

public class PaymentApptDaoTest extends TestCase {

	PaymentAppDao dao = new PaymentAppDao();
	PaymentAppDetails details = new PaymentAppDetails();
	BankDetails bank= new BankDetails();
	public void testAddCustomerDetail() {
		Assert.assertEquals(true,dao.addCustomerDetail(bank));
	}

	public void testShowBalance() {
		
		Assert.assertEquals(0.0, dao.showBalance());
		
	}

	public void testDepositAmount() {
		Assert.assertEquals(true, dao.depositAmount(1000));
	}

	public void testWithdrawAmount() {
		
		Assert.assertEquals(true, dao.withdrawAmount(2000));
	}

	
	public void testFundTransfer() {
		Assert.assertEquals(true, dao.fundTransfer(1212356, 1000));
	}

	
}
