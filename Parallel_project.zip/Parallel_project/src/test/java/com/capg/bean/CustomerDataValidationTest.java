package com.capg.bean;

import junit.framework.TestCase;

public class CustomerDataValidationTest extends TestCase {

	public void testValidateAadharNo() {
		fail("Not yet implemented");
	}

	public void testValidateMobileNo() {
		fail("Not yet implemented");
	}

	public void testValidatePassword() {
		fail("Not yet implemented");
	}
	public void testValidateInitBal() {
		fail("Not yet implemented");
	}


}
