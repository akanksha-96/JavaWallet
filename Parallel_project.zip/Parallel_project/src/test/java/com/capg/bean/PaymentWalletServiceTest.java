package com.capg.bean;

import junit.framework.TestCase;

public class PaymentWalletServiceTest extends TestCase {

	public void testAddCustomerDetail() {
		
	}

	public void testShowBalance() {
		fail("Not yet implemented");
	}

	public void testDepositAmount() {
		fail("Not yet implemented");
	}

	public void testWithdrawAmount() {
		fail("Not yet implemented");
	}

	public void testLoginAccount() {
		fail("Not yet implemented");
	}

	public void testFundTransfer() {
		fail("Not yet implemented");
	}

	public void testPrintTransaction() {
		fail("Not yet implemented");
	}

}
