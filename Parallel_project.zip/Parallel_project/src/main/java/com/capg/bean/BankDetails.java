package com.capg.bean;

import java.time.LocalDate;
import java.util.List;

public class BankDetails 
{
	private String name;
	private LocalDate aodate;
	private long accNumber;
	PaymentAppDetails acc;
	private float custInitBal;
	private float custBal;
	private String pass;
	private List<String> transaction;
	
	
	public List<String> getTransaction() {
		return transaction;
	}
	public void setTransaction(List<String> transaction) {
		this.transaction = transaction;
	}
	public String getPass() {
		return pass;
	}
	public void setPass(String pass) {
		this.pass = pass;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public LocalDate getAodate() {
		return aodate;
	}
	public void setAodate(LocalDate aodate) {
		this.aodate = aodate;
	}
	public long getAccNumber() {
		return accNumber;
	}
	public void setAccNumber(long accNumber) {
		this.accNumber = accNumber;
	}
	public PaymentAppDetails getAcc() {
		return acc;
	}
	public void setAcc(PaymentAppDetails acc) {
		this.acc = acc;
	}
	public float getCustInitBal() {
		return custInitBal;
	}
	public void setCustInitBal(float custInitBal) {
		this.custInitBal = custInitBal;
	}
	public float getCustBal() {
		return custBal;
	}
	public void setCustBal(float custBal) {
		this.custBal = custBal;
	}
	@Override
	public String toString() {
		return "BankDetails [name=" + name + ", aodate=" + aodate + ", accNumber=" + accNumber + ", acc=" + acc
				+ ", custInitBal=" + custInitBal + ", custBal=" + custBal + "]";
	}
	
	
	
}