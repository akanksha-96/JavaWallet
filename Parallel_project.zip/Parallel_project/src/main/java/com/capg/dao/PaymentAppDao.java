package com.capg.dao;
import java.util.HashMap;
import java.util.List;

import com.capg.bean.BankDetails;
import com.capg.bean.PaymentAppDetails;

public class PaymentAppDao implements IPaymentAppDao {

	public static HashMap<String, BankDetails> map = new HashMap<String, BankDetails>();
	public static BankDetails bank;
	static PaymentAppDetails acc;

	long transactionId = (long) ((Math.random() * 123) + 999);


	public boolean addCustomerDetail(BankDetails account) {
		boolean b= true;
		if (b) {
		map.put(account.getName(), account);
		b=true;
		}
		else {
			System.out.println("Account not created!");
			b=false;
		}return b;
	}

	public float showBalance() {

		return bank.getCustBal();
		
	}

	public boolean depositAmount(float amount) {
		// System.out.println("HELL");
		bank.setCustBal(bank.getCustBal() + amount);
		String dep = transactionId + "    Amount deposited is:   " +amount;
		bank.getTransaction().add(dep);
		return true;

	}

	public boolean withdrawAmount(float amount) {

		if (bank.getCustBal() >= amount) {
			bank.setCustBal(bank.getCustBal() - amount);
			String with =transactionId + "    Amount withdrawn is:   "+amount;
			bank.getTransaction().add(with);
			return true;
		} else {
			System.out.println("Insufficient funds");
		}
		return false;

	}

	public boolean fundTransfer(long recieverAccountNum, float amount) {
		for (String key : map.keySet()) {
			BankDetails recieverAccount = map.get(key);
			if (recieverAccount.getAccNumber() == recieverAccountNum) {
				recieverAccount.setCustBal(recieverAccount.getCustBal() + amount);
				bank.setCustBal(bank.getCustBal() - amount);
				String transfer =transactionId + "  Amount  is transferred:   " +amount;
				bank.getTransaction().add(transfer);
				return true;
			}

		}
		return false;
	}

	public boolean loginAccount(String name, String pass) {

		for (String key : map.keySet()) {
			bank = map.get(key);
			if (bank.getName().equals(name) && bank.getPass().equals(pass)) {
				return true;
			} else {
				System.out.println("Enter valid name or password!!");
			}
		}
		return false;
	}

	public List<String> printTransaction() {
		return bank.getTransaction();
	}


}
